import { ElementHandle, Page } from '@playwright/test';
import { SidebarHelper } from './sidebar';
import { NotebookHelper } from './notebook';
/**
 * Debugger Helper
 */
export declare class DebuggerHelper {
    readonly page: Page;
    readonly sidebar: SidebarHelper;
    readonly notebook: NotebookHelper;
    constructor(page: Page, sidebar: SidebarHelper, notebook: NotebookHelper);
    /**
     * Returns true if debugger toolbar item is enabled, false otherwise
     */
    isOn(): Promise<boolean>;
    /**
     * Enables the debugger toolbar item
     */
    switchOn(): Promise<void>;
    /**
     * Disables the debugger toolbar item
     */
    switchOff(): Promise<void>;
    /**
     *  Returns true if debugger panel is open, false otherwise
     */
    isOpen(): Promise<boolean>;
    /**
     * Returns handle to the variables panel content
     */
    getVariablesPanel(): Promise<ElementHandle<Element> | null>;
    /**
     * Waits for variables to be populated in the variables panel
     */
    waitForVariables(): Promise<void>;
    /**
     * render variable
     */
    renderVariable(name: string): Promise<void>;
    /**
     * Returns handle to callstack panel content
     */
    getCallStackPanel(): Promise<ElementHandle<Element> | null>;
    /**
     * Waits for the callstack body to populate in the callstack panel
     */
    waitForCallStack(): Promise<void>;
    /**
     * Returns handle to breakpoints panel content
     */
    getBreakPointsPanel(): Promise<ElementHandle<Element> | null>;
    /**
     * Waits for the breakpoints to appear in the breakpoints panel
     */
    waitForBreakPoints(): Promise<void>;
    /**
     * Returns handle to sources panel content
     */
    getSourcePanel(): Promise<ElementHandle<Element> | null>;
    /**
     * Waits for sources to be populated in the sources panel
     */
    waitForSources(): Promise<void>;
    private _getPanel;
}
