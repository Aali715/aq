import { Page } from '@playwright/test';
interface IUnusedStyleCheckOptions {
    /**
     * List of rule fragments to match rules for runtime checks.
     */
    fragments: string[];
    /**
     * List of fragments to filter out rules which cannot (easily) be checked at runtime.
     */
    exclude?: string[];
    /**
     * Whether to check rules with pseudo-classes.
     *
     * Default: false.
     */
    includePseudoClasses?: boolean;
    /**
     * Whether to include rules matching mod classes (`jp-mod-` and `.lm-mod-`).
     *
     * Default: false.
     */
    includeModifiers?: boolean;
}
/**
 * CSS Style analysis helpers
 */
export declare class StyleHelper {
    readonly page: Page;
    constructor(page: Page);
    /**
     * Collect all CSS selectors on page.
     */
    collectAllSelectors(): Promise<string[]>;
    /**
     * Find unused CSS rules.
     *
     * @param options spcify which rules to include/exclude.
     * @returns List of rules with no matching elements on the page.
     */
    findUnusedStyleRules(options: IUnusedStyleCheckOptions): Promise<string[]>;
}
export {};
