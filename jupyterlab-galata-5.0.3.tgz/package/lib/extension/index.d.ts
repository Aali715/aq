import { JupyterFrontEndPlugin } from '@jupyterlab/application';
import { IGalataHelpers } from './tokens';
export type { IGalataInpage, INotebookRunCallback, IPluginNameToInterfaceMap, IWaitForSelectorOptions } from './tokens';
export { IGalataHelpers } from './tokens';
declare const galataPlugin: JupyterFrontEndPlugin<IGalataHelpers>;
export default galataPlugin;
