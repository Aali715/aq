import type { JupyterFrontEnd } from '@jupyterlab/application';
import type { Dialog, Notification } from '@jupyterlab/apputils';
import type { Cell, MarkdownCell } from '@jupyterlab/cells';
import type * as nbformat from '@jupyterlab/nbformat';
import { IGalataInpage, INotebookRunCallback, IPluginNameToInterfaceMap, IWaitForSelectorOptions } from './tokens';
/**
 * In-Page Galata helpers
 */
export declare class GalataInpage implements IGalataInpage {
    /**
     * Get an application plugin
     *
     * @param pluginId Plugin ID
     * @returns Application plugin
     */
    getPlugin<K extends keyof IPluginNameToInterfaceMap>(pluginId: K): Promise<IPluginNameToInterfaceMap[K] | undefined>;
    /**
     * Get the Jupyter notifications
     *
     * @returns Jupyter Notifications
     */
    getNotifications(): Promise<Notification.INotification[]>;
    /**
     * Disconnect a listener to new Jupyter dialog events.
     *
     * @param event Event type
     * @param listener Event listener
     */
    off(event: 'dialog', listener: (dialog: Dialog<any> | null) => void): void;
    /**
     * Disconnect a listener to new or updated Jupyter notification events.
     *
     * @param event Event type
     * @param listener Event listener
     */
    off(event: 'notification', listener: (notification: Notification.INotification) => void): void;
    /**
     * Connect a listener to new Jupyter dialog events.
     *
     * @param event Event type
     * @param listener Event listener
     */
    on(event: 'dialog', listener: (dialog: Dialog<any> | null) => void): void;
    on(event: 'notification', listener: (notification: Notification.INotification) => void): void;
    /**
     * Connect a listener to the next new Jupyter dialog event.
     *
     * @param event Event type
     * @param listener Event listener
     */
    once(event: 'dialog', listener: (dialog: Dialog<any> | null) => void): void;
    /**
     * Connect a listener to the next new or updated Jupyter notification event.
     *
     * @param event Event type
     * @param listener Event listener
     */
    once(event: 'notification', listener: (notification: Notification.INotification) => void): void;
    /**
     * Wait for a function to finish for max. timeout milliseconds
     *
     * @param fn Function
     * @param timeout Timeout
     */
    waitForFunction(fn: Function, timeout?: number): Promise<void>;
    /**
     * Waits for the given `timeout` in milliseconds.
     *
     * @param timeout A timeout to wait for
     */
    waitForTimeout(timeout: number): Promise<void>;
    /**
     * Wait for a condition to fulfill or for a certain time
     *
     * @param condition Condition or timeout to wait for
     * @param timeout Timeout
     */
    waitFor(condition: Function | number, timeout?: number): Promise<void>;
    /**
     * Wait for the route to be on path and close all documents
     *
     * @param path Path to monitor
     */
    waitForLaunch(path?: string): Promise<void>;
    /**
     * Wait for an element to be found from a CSS selector
     *
     * @param selector CSS selector
     * @param node Element
     * @param options Options
     * @returns Selected element
     */
    waitForSelector(selector: string, node?: Element, options?: IWaitForSelectorOptions): Promise<Node | null>;
    /**
     * Wait for an element to be found from a XPath
     *
     * @param selector CSS selector
     * @param node Element
     * @param options Options
     * @returns Selected element
     */
    waitForXPath(selector: string, node?: Element, options?: IWaitForSelectorOptions): Promise<Node | null>;
    /**
     * Delete all cells of the active notebook
     */
    deleteNotebookCells(): Promise<void>;
    /**
     * Add a cell to the active notebook
     *
     * @param cellType Cell type
     * @param source Cell input source
     * @returns Action success result
     */
    addNotebookCell(cellType: nbformat.CellType, source: string): boolean;
    /**
     * Reset execution count of one or all cells.
     *
     * @param cellIndex Cell index
     */
    resetExecutionCount(cellIndex?: number): void;
    /**
     * Set the type and content of a cell in the active notebook
     *
     * @param cellIndex Cell index
     * @param cellType Cell type
     * @param source Cell input source
     * @returns Action success status
     */
    setNotebookCell(cellIndex: number, cellType: nbformat.CellType, source: string): boolean;
    /**
     * Test if a cell is selected in the active notebook
     *
     * @param cellIndex Cell index
     * @returns Whether the cell is selected or not
     */
    isNotebookCellSelected(cellIndex: number): boolean;
    /**
     * Save the active notebook
     */
    saveActiveNotebook(): Promise<void>;
    /**
     * Wait for a Markdown cell to be rendered
     *
     * @param cell Cell
     */
    waitForMarkdownCellRendered(cell: MarkdownCell): Promise<void>;
    /**
     * Wait for a cell to be run
     *
     * @param cell Cell
     * @param timeout Timeout
     */
    waitForCellRun(cell: Cell, timeout?: number): Promise<void>;
    /**
     * Run the active notebook cell by cell
     * and execute the callback after each cell execution
     *
     * @param callback Callback
     */
    runActiveNotebookCellByCell(callback?: INotebookRunCallback): Promise<void>;
    /**
     * Test if one or all cells have an execution number.
     *
     * @param cellIndex Cell index
     * @returns Whether the cell was executed or not
     *
     * ### Notes
     * It checks that no cells have a `null` execution count.
     */
    haveBeenExecuted(cellIndex?: number): boolean;
    /**
     * Get the index of a toolbar item
     *
     * @param itemName Item name
     * @returns Index
     */
    getNotebookToolbarItemIndex(itemName: string): number;
    /**
     * Test if a element is visible or not
     *
     * @param el Element
     * @returns Test result
     */
    isElementVisible(el: HTMLElement): boolean;
    /**
     * Set the application theme
     *
     * @param themeName Theme name
     */
    setTheme(themeName: string): Promise<void>;
    /**
     * Application object
     */
    get app(): JupyterFrontEnd;
    private _app;
    protected listeners: WeakMap<(arg: unknown) => void, (sender: unknown, args: unknown) => void>;
}
