import type * as nbformat from '@jupyterlab/nbformat';
import type { Session, TerminalAPI, User, Workspace } from '@jupyterlab/services';
import type { ISettingRegistry } from '@jupyterlab/settingregistry';
import type { JSONObject } from '@lumino/coreutils';
import type { APIRequestContext, Browser, Page } from '@playwright/test';
import { ContentsHelper } from './contents';
import { PerformanceHelper } from './helpers';
import { IJupyterLabPage, IJupyterLabPageFixture } from './jupyterlabpage';
/**
 * Galata namespace
 */
export declare namespace galata {
    /**
     * Default user settings:
     * - Deactivate codemirror cursor blinking to avoid noise in screenshots
     */
    const DEFAULT_SETTINGS: Record<string, any>;
    const DEFAULT_DOCUMENTATION_STATE: Record<string, any>;
    /**
     * Sidebar position
     */
    type SidebarPosition = 'left' | 'right';
    /**
     * Default sidebar ids
     */
    type DefaultSidebarTabId = 'filebrowser' | 'jp-running-sessions' | 'jp-property-inspector' | 'table-of-contents' | 'extensionmanager.main-view' | 'jp-debugger-sidebar';
    /**
     * Sidebar id type
     */
    type SidebarTabId = DefaultSidebarTabId | string;
    /**
     * Default toolbar item ids
     */
    type DefaultNotebookToolbarItemId = 'save' | 'insert' | 'cut' | 'copy' | 'paste' | 'run' | 'interrupt' | 'restart' | 'restart-and-run' | 'cellType' | 'kernelName' | 'kernelStatus';
    /**
     * Notebook toolbar item type
     */
    type NotebookToolbarItemId = DefaultNotebookToolbarItemId | string;
    /**
     * Options to create a new page
     */
    interface INewPageOption {
        /**
         * Application base URL
         */
        baseURL: string;
        /**
         * Playwright browser model
         */
        browser: Browser;
        /**
         * Callback that resolved when the application page is ready
         */
        waitForApplication: (page: Page, helpers: IJupyterLabPage) => Promise<void>;
        /**
         * Application URL path fragment
         *
         * Default: /lab
         */
        appPath?: string;
        /**
         * Whether to go to JupyterLab page within the fixture or not.
         *
         * Default: true
         */
        autoGoto?: boolean;
        /**
         * Mock Jupyter Server configuration in-memory or not.
         *
         * Default true
         */
        mockConfig?: boolean | Record<string, unknown>;
        /**
         * Mock JupyterLab state in-memory or not.
         *
         * Default galata.DEFAULT_SETTINGS
         */
        mockSettings?: boolean | Record<string, unknown>;
        /**
         * Mock JupyterLab settings in-memory or not.
         *
         * Default true
         */
        mockState?: boolean | Record<string, unknown>;
        /**
         * Mock JupyterLab user in-memory or not.
         *
         * Default true
         */
        mockUser?: boolean | Partial<User.IUser>;
        /**
         * Whether to store sessions in memory or not.
         *
         * Default true
         */
        mockSessions?: boolean;
        /**
         * Whether to store terminals in memory or not.
         *
         * Default true
         */
        mockTerminals?: boolean;
        /**
         * Create and delete a temporary path during the page existence
         *
         * Default ''
         */
        tmpPath?: string;
    }
    /**
     * Add the Galata helpers to the page model
     *
     * @param page Playwright page model
     * @param baseURL Application base URL
     * @param waitForApplication Callback that resolved when the application page is ready
     * @param appPath Application URL path fragment
     * @returns Playwright page model with Galata helpers
     */
    function addHelpersToPage(page: Page, baseURL: string, waitForApplication: (page: Page, helpers: IJupyterLabPage) => Promise<void>, appPath?: string): IJupyterLabPageFixture;
    function initTestPage(appPath: string, autoGoto: boolean, baseURL: string, mockConfig: boolean | Record<string, unknown>, mockSettings: boolean | Record<string, unknown>, mockState: boolean | Record<string, unknown>, mockUser: boolean | Partial<User.IUser>, page: Page, sessions: Map<string, Session.IModel> | null, terminals: Map<string, TerminalAPI.IModel> | null, tmpPath: string, waitForApplication: (page: Page, helpers: IJupyterLabPage) => Promise<void>): Promise<IJupyterLabPageFixture>;
    /**
     * Create a contents REST API helpers object
     *
     * @param request Playwright API request context
     * @param page Playwright page model
     * @returns Contents REST API helpers
     */
    function newContentsHelper(request?: APIRequestContext, page?: Page): ContentsHelper;
    /**
     * Create a page with Galata helpers for the given browser in a new context.
     *
     * @returns Playwright page model with Galata helpers
     */
    function newPage(options: INewPageOption): Promise<{
        page: IJupyterLabPageFixture;
        sessions: Map<string, Session.IModel> | null;
        terminals: Map<string, TerminalAPI.IModel> | null;
    }>;
    /**
     * Create a new performance helper
     *
     * @param page Playwright page model
     * @returns Performance helper
     */
    function newPerformanceHelper(page: Page): PerformanceHelper;
    /**
     * Regex to capture JupyterLab API call
     */
    namespace Routes {
        /**
         * Config API
         *
         * The config section can be found in the named group `section`.
         */
        const config: RegExp;
        /**
         * Contents API
         *
         * The content path can be found in the named group `path`.
         *
         * The path will be prefixed by '/'.
         * The path will be undefined for the root folder.
         */
        const contents: RegExp;
        /**
         * Extensions API
         */
        const extensions: RegExp;
        /**
         * Sessions API
         *
         * The session id can be found in the named group `id`.
         *
         * The id will be prefixed by '/'.
         */
        const sessions: RegExp;
        /**
         * Settings API
         *
         * The schema name can be found in the named group `id`.
         *
         * The id will be prefixed by '/'.
         */
        const settings: RegExp;
        /**
         * Terminals API
         *
         * The terminal id can be found in the named group `id`.
         *
         * The id will be prefixed by '/'.
         */
        const terminals: RegExp;
        /**
         * Translations API
         *
         * The locale can be found in the named group `id`.
         *
         * The id will be prefixed by '/'.
         */
        const translations: RegExp;
        /**
         * Workspaces API
         *
         * The space name can be found in the named group `id`.
         *
         * The id will be prefixed by '/'.
         */
        const workspaces: RegExp;
        /**
         * User API
         */
        const user: RegExp;
    }
    /**
     * Notebook generation helpers
     */
    namespace Notebook {
        /**
         * Generate a notebook with identical cells
         *
         * @param nCells Number of cells
         * @param cellType Type of cells
         * @param defaultInput Default input source
         * @param defaultOutput Default outputs
         * @returns The notebook
         */
        function generateNotebook(nCells?: number, cellType?: nbformat.CellType, defaultInput?: string[], defaultOutput?: nbformat.IOutput[]): nbformat.INotebookContent;
        /**
         * Generate a cell object
         *
         * @param skeleton Cell description template
         * @returns A cell
         */
        function makeCell(skeleton: Partial<nbformat.ICell>): nbformat.ICell;
        /**
         * Generate a notebook object from a cell list
         *
         * @param cells Notebook cells
         * @returns Notebook
         */
        function makeNotebook(cells: Array<nbformat.ICell>): nbformat.INotebookContent;
    }
    /**
     * Mock methods
     */
    namespace Mock {
        /**
         * Set last modified attributes one day ago one listing
         * directory content.
         *
         * @param page Page model object
         *
         * #### Notes
         * The goal is to freeze the file browser display
         */
        function freezeContentLastModified(page: Page): Promise<void>;
        /**
         * Clear all wanted sessions or terminals.
         *
         * @param baseURL Application base URL
         * @param runners Session or terminal ids to stop
         * @param type Type of runner; session or terminal
         * @param request API request context
         * @returns Whether the runners were closed or not
         */
        function clearRunners(request: APIRequestContext, runners: string[], type: 'sessions' | 'terminals'): Promise<boolean>;
        /**
         * Mock config route.
         *
         * @param page Page model object
         * @param config In-memory config
         */
        function mockConfig(page: Page, config: Record<string, JSONObject>): Promise<void>;
        /**
         * Mock the runners API to display only those created during a test
         *
         * @param page Page model object
         * @param runners Mapping of current test runners
         * @param type Type of runner; session or terminal
         */
        function mockRunners(page: Page, runners: Map<string, any>, type: 'sessions' | 'terminals'): Promise<void>;
        /**
         * Mock workspace route.
         *
         * @param page Page model object
         * @param workspace In-memory workspace
         */
        function mockState(page: Page, workspace: Workspace.IWorkspace): Promise<void>;
        /**
         * Mock settings route.
         *
         * @param page Page model object
         * @param settings In-memory settings
         * @param mockedSettings Test mocked settings
         */
        function mockSettings(page: Page, settings: ISettingRegistry.IPlugin[], mockedSettings: Record<string, any>): Promise<void>;
        /**
         * Mock user route.
         *
         * @param page Page model object
         * @param user In-memory user
         */
        function mockUser(page: Page, user: User.IUser): Promise<void>;
    }
}
